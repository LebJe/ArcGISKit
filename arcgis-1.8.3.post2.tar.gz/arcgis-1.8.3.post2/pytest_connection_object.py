import sys
sys.path.insert(0, r"C:\SVN\achapkowski_geosaurus_fork_requests_take2\src")
import pytest
import unittest
from arcgis.gis._impl._con import Connection

class TestConnection(unittest.TestCase):
    pass

if __name__ == "__main__":
    #unittest.main()
    pass
