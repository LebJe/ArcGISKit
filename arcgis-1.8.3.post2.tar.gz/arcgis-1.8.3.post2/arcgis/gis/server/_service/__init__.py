"""
Classes for ArcGIS Services
"""
from __future__ import absolute_import
from ._layerfactory import Service

__version__ = "1.8.3"
__all__ = ['Service']
